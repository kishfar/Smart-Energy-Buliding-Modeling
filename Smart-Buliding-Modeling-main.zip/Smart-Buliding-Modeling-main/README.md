# Smart-Buliding-Modeling
A net zero energy building with WT, PV, Battery and GSHP for two different cities
This model is developed to calculate the annual energy demand of a smart building. The inputs of this model should be temperature profile of your case study and wind speed profile and heat demand.
After all I put two case study (Tehran and, Ottawa) as an ilusteration.
